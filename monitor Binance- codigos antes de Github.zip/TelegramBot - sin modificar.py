import requests

class MiBotTelegram:
    def __init__(self):
        self.token = "tu_token_de_bot"
        self.url_base = f"https://api.telegram.org/bot{self.token}/"
        self.ultimo_id = None

    def obtener_actualizaciones(self):
        res = requests.get(self.url_base + "getUpdates")
        return res.json()

    def consultar_bot_telegram(self):
        actualizaciones = self.obtener_actualizaciones()
        mensajes_nuevos = []
        for actualizacion in actualizaciones["result"]:
            id_actualizacion = actualizacion["update_id"]
            if id_actualizacion > self.ultimo_id:
                self.ultimo_id = id_actualizacion
                mensajes_nuevos.append(actualizacion["message"]["text"])
        return mensajes_nuevos

    def notificar_en_bot_telegram(self, mensaje):
        chat_id = "tu_chat_id"
        params = {"chat_id": chat_id, "text": mensaje}
        res = requests.post(self.url_base + "sendMessage", params)
        return res.json()
