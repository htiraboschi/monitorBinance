# -*- coding: utf-8 -*-
"""
Created on Wed Oct 18 23:26:13 2023

@author: htiraboschi
"""

import time
from datetime import datetime
import TelegramBot
import ccxt
import re

PAUSA_BINANCE = 1000 #pausa entre consultas a Binances. Unidad: milisegundos

def parsear_regla(regla):
    # Definir el patrón de la regla
    patron = r"\+(\w+\/\w+)([<>])([\d,]+)"

    # Intentar hacer coincidir el patrón con la cadena
    coincidencia = re.match(patron, regla)

    if coincidencia:
        # Si hay una coincidencia, extraer los grupos
        operador, simbolo, valor = coincidencia.groups()
        valor = float(valor.replace(',', '.'))
        reglaOk = True
    else:
        # Si no hay una coincidencia, establecer las variables en None
        operador, simbolo, valor, reglaOk = None, None, None, False
        
    return operador, simbolo, valor, reglaOk

def evaluar_regla(regla):
    try:
        # Descomponer la regla
        operador,comparador,valor,reglaOk = parsear_regla(regla)
        if not reglaOk:
            return False, False

        # Crear instancia de Binance
        binance = ccxt.binance()

        # Obtener el precio actual
        precio_actual = binance.fetch_ticker(operador.upper())['last']
        # Evaluar la regla
        if comparador == '<':
            return True, precio_actual < valor
        elif comparador == '>':
            return True, precio_actual > valor
        else:
            return False, False
    except:
        return False, False
    
def registrar_log(mensaje):
    with open('log.txt', 'a') as f:
        f.write(f'{datetime.now()} {mensaje}\n')

def validar_en_binance(regla):
    reglaValida , reglaResultado = evaluar_regla(regla)
    return reglaValida

def evaluar_en_binance(regla):
    reglaValida , reglaResultado = evaluar_regla(regla)
    return reglaResultado

def mover_entradas_log():
    # Implementa esta función para mover las entradas del log del mes pasado
    pass

# Inicio de ejecución
registrar_log('inicio de ejecución')

try:
    # Consultar bot de Telegram
    mensajes = TelegramBot.MiBotTelegram().consultar_bot_telegram()
    for mensaje in mensajes:
        # Verificar si el mensaje es una regla que se puede evaluar en Binance
        if validar_en_binance(mensaje):
            # Agregar la regla al archivo de reglas y registrar en el log
            with open('reglas.txt', 'a') as f:
                f.write(f'{mensaje}\n')
            registrar_log(f'nueva regla {mensaje}')

    # Evaluar cada regla en Binance
    with open('reglas.txt', 'r') as f:
        reglas = f.readlines()
    with open('reglas.txt', 'w') as f:
        for regla in reglas:
            if evaluar_en_binance(regla):
                # Si la regla se cumple, registrar en el log y notificar en el bot de Telegram
                registrar_log(f'regla verificada {regla}')
                TelegramBot.MiBotTelegram().notificar_en_bot_telegram(f'Regla verificada: {regla}')
            else:
                # Si la regla no se cumple, mantener la regla en el archivo
                f.write(regla)
            time.sleep(PAUSA_BINANCE / 1000)

    # Mover entradas del log del mes pasado
    mover_entradas_log()

except Exception as e:
    # Si ocurre un error, notificar en el bot de Telegram y registrar en el log
    TelegramBot.MiBotTelegram().notificar_en_bot_telegram(f'Error: {str(e)}')
    registrar_log(f'Error: {str(e)}')

# Fin de ejecución
registrar_log('fin ejecución')
